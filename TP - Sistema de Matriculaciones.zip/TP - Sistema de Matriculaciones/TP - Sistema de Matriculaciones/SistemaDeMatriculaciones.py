
##########################################################
# Sofía de Bérail - Valentin Ferrando - Victoria Maneiro #
##########################################################

import json

class GestorJSON:
    """ Clase para gestionar archivos en formato JSON que contienen información de estudiantes. Permite abrir, guardar, agregar y eliminar registros. """
    
    @staticmethod
    def abrir_json(ruta:str) -> list: 
        """Abre un archivo JSON y retorna su contenido como lista de diccionarios.

        Parámetro:
            ruta (str): Ruta del archivo JSON a abrir.

        Retorna:
            list: Lista de diccionarios almacenados en el archivo."""
        
        try:
            with open(ruta, 'r', encoding='utf-8') as archivo:
                datos = json.load(archivo)
        
        except FileNotFoundError:
            raise FileNotFoundError(f"Error: El archivo '{ruta}' no existe.")
            
        except Exception as e:
            raise Exception(f"Error inesperado al abrir el archivo: {e}")
        
        else:
            return datos

    @staticmethod
    def guardar_json(ruta:str, datos:list) -> None:
        """Guarda una lista de diccionarios en un archivo JSON.

        Parámetros:
            ruta (str): Ruta del archivo JSON donde se guardarán los datos.
            datos (list): Lista de diccionarios con los datos a guardar."""
        
        try:
            with open(ruta, mode="w", encoding="utf-8") as archivo:
                json.dump(datos, archivo, indent= 4, ensure_ascii=False)
        
        except TypeError:
            raise TypeError("Error: Los datos a guardar no son serializables como JSON.")
        
        except IOError:
            raise IOError(f"Error: No se pudo abrir el archivo {ruta} para escribir.")
        
        except Exception as e:
            raise Exception(f"Error inesperado al guardar el archivo: {e}")

    @staticmethod
    def agregar_estudiante(ruta:str, nuevo_estudiante:dict) -> str:
        """Agrega un nuevo estudiante al archivo JSON.

        Parámetros:
            ruta (str): Ruta del archivo JSON donde se almacena la base de datos.
            nuevo_estudiante (dict): Diccionario con los datos del estudiante a agregar."""
        
        datos_estudiantes = GestorJSON.abrir_json(ruta)
            
        datos_estudiantes.append(nuevo_estudiante)
        
        GestorJSON.guardar_json(ruta, datos_estudiantes)
    
    @staticmethod
    def eliminar_estudiante(ruta:str, indice_estudiante: int) -> str:
        """Elimina un estudiante del archivo JSON.

        Parámetros:
            ruta (str): Ruta del archivo JSON donde se almacena la base de datos.
            indice_estudiante (int): Posición dentro del archivo JSON donde se encuentra del estudiante a eliminar."""

        datos_estudiantes = GestorJSON.abrir_json(ruta)
        
        datos_estudiantes.pop(indice_estudiante)
                
        GestorJSON.guardar_json(ruta, datos_estudiantes)
    
    @staticmethod
    def modificar_info_carrera(ruta: str, carrera: str, clave: str, nuevo_valor) -> str:
        """Modifica el valor de una clave específica en la información de una carrera dentro del archivo JSON.

        Parámetros:
            ruta (str): Ruta del archivo JSON donde se almacena la información de las carreras.
            carrera (str): Nombre de la carrera cuya información se desea modificar.
            clave (str): Clave dentro de la carrera a modificar.
            nuevo_valor: Nuevo valor que se desea asignar a la clave especificada.

        Retorna:
            str: Mensaje indicando si la modificación fue exitosa o no."""
        
        datos = GestorJSON.abrir_json(ruta)
       
        datos[carrera][clave] = nuevo_valor
            
        GestorJSON.guardar_json(ruta, datos)

    @staticmethod
    def agregar_carrera(ruta: str, nombre_carrera: str, datos_carrera: dict) -> str:
        """Agrega una nueva carrera al archivo JSON de información de las carreras.

        Parámetros:
            ruta (str): Ruta del archivo JSON donde se almacena la información de las carreras.
            nombre_carrera (str): Nombre identificador de la nueva carrera.
            datos_carrera (dict): Diccionario con la estructura y datos correspondientes a la nueva carrera.

        Retorna:
            str: Mensaje indicando si el agregado fue exitoso o no."""
        
        datos = GestorJSON.abrir_json(ruta)
        
        datos[nombre_carrera] = datos_carrera
        
        GestorJSON.guardar_json(ruta, datos)
        

class PlanEstudio:
    """ Clase que gestiona un plan de estudio a partir de un archivo JSON.
        Permite acceder a información sobre unidades curriculares, validar requisitos y calcular créditos."""
    
    def __init__(self, ruta_carreras: str, carrera:str):
        """Inicializa el plan de estudio de una determinada carrera.

        Parámetros:
            ruta_carreras (str): Ruta al archivo JSON con información de todas las carreras.
            carrera (str): Carrera asociada al plan de estudios."""
        
        info_carreras = GestorJSON.abrir_json(ruta_carreras)
        self.__carrera = carrera
        
        if carrera not in info_carreras:
            raise ValueError(f"La carrera '{carrera}' no está registrada.")
        
        ruta_plan = info_carreras[carrera]["plan_path"]
        self.__plan = GestorJSON.abrir_json(ruta_plan)
    
    @property
    def plan(self) -> list: 
        """Obtiene el plan de estudio de la carrera."""
        return self.__plan
    
    @property
    def carrera(self) -> list:
        """Obtiene la carrera del plan de estudio."""
        return self.__carrera
    
    def ucs_por_semestre(self, semestre: int) -> list:
        """Obtiene todas las Unidades Curriculares (UC) correspondientes a un semestre específico.

        Parámetro:
            semestre (int): Número del semestre (entre 1 y 10).

        Retorna:
            list: Lista de UC del semestre especificado.
            str: Mensaje de error si el semestre no es válido."""
        
        if not (1 <= semestre <= 10):
            return f"El semestre {semestre} no existe en el plan de estudio."
        
        else:
            return [uc for uc in self.__plan if uc["Semestre"] == semestre]
    
    def info_uc(self, codigo: str) -> dict:
        """Obtiene la información de una UC por su código.

        Parámetro:
            codigo (str): Código de la UC a buscar.

        Retorna:
            dict: Información de la UC con el código proporcionado.
            str: Mensaje de error si no se encuentra la UC."""
            
        error = self._verificar_codigo_uc(codigo)
        
        if error is not None:
            return error
        
        for uc in self.__plan:
        
            if uc["Código"] == codigo:
                return uc
    
    def previas_de_uc(self, codigo: str) -> dict:
        """Obtiene las UC previas de una UC especificada.

        Parámetro:
            codigo (str): Código de la UC para la cual se desean conocer las previas.

        Retorna:
            dict: Diccionario de las UC previas.
            str: Mensaje de error si la UC no tiene previas o no se encuentra."""
        
        error = self._verificar_codigo_uc(codigo)
        
        if error is not None:
            return error
        
        for uc in self.__plan:
            
            if uc["Código"] == codigo:
                
                if uc["Previaturas"] != {}:
                    return uc["Previaturas"]
                
                else:
                    return f"La UC '{codigo}' no tiene previas."
    
    def ucs_indice(self) -> list:
        """Obtiene un índice con los códigos y nombres de todas las UC.

        Retorna:
            list: Lista de tuplas con el código y nombre de cada UC."""
        
        return [(uc["Código"], uc["Nombre"]) for uc in self.__plan]
    
    def ucs_dependientes(self, codigo_previa: str) -> list:
        """Obtiene las UC que dependen de una UC previa específica.

        Parámetro:
            codigo_previa (str): Código de la UC previa a buscar.

        Retorna:
            list: Lista de nombres de UC dependientes de la UC previa.
            str: Mensaje de error si no se encuentra la UC previa o no tiene dependientes."""
            
        error = self._verificar_codigo_uc(codigo_previa)
        
        if error is not None:
            return error

        dependientes = [uc["Nombre"] for uc in self.__plan if codigo_previa in uc["Previaturas"]]

        if dependientes != []:
            return dependientes
        
        else:
            return f"La UC con el código '{codigo_previa}' no es previa de ninguna UC."
        
    def sumar_creditos(self, codigos: list) -> int:
        """Suma los créditos de las Unidades Curriculares (UC) cuyos códigos se pasan como lista.

        Parámetro:
            codigos (list): Lista de códigos de las UCs a sumar.

        Retorna:
            int: Suma total de créditos de las UCs."""
       
        total_creditos = 0
        
        errores = []

        for codigo in codigos:
            
            error = self._verificar_codigo_uc(codigo)
            
            if error is not None:
                errores.append(error)
            
            for uc in self.__plan:
                    
                if uc["Código"] == codigo:
                        
                    total_creditos += uc["Créditos"]
                        
                    break

        if errores != []:
            return " - ".join(errores)
        
        return total_creditos
    
    def _verificar_codigo_uc(self, codigo:str) -> None:
        """Verifica si una Unidad Curricular (UC) con el código dado existe en el plan de estudios.

        Parámetro:
            codigo (str): Código de la unidad curricular a verificar.

        Retorna:
            Optional[str]: Mensaje de error si el código no existe, o None si es válido."""    
       
        codigos_existentes = [uc["Código"] for uc in self.__plan]
        
        if codigo not in codigos_existentes:
            return f"No existe una UC con el código '{codigo}'."
        
        else:
            return None

class Sistema:
    """ Clase para gestionar la base de datos de los estudiantes y un sistema de matriculaciones. 
        Administra inscripciones, calificaciones, y estados académicos según el plan de estudio asociado."""
    
    # --------------------------------- MÉTODOS DE INICIALIZACIÓN Y VERIFICACIÓN ---------------------------------
    def __init__(self, ruta_carreras: str, plan: object):
        """Inicializa el sistema con un plan de estudios y carga la información necesaria."""
        self.__plan = plan
        self.carrera = plan.carrera
        self.ruta_carreras = ruta_carreras
        self.info_carreras = GestorJSON.abrir_json(ruta_carreras)
        ruta_estudiantes = self.info_carreras[self.carrera]["estudiantes_path"]
        self.__ruta_estudiantes = ruta_estudiantes
        self.__datos_estudiantes = GestorJSON.abrir_json(ruta_estudiantes)

    @property
    def datos_estudiantes(self) -> list:
        """Retorna la base de datos de estudiantes."""
        return self.__datos_estudiantes

    def _verificar_secretaria(self, nombre, apellido, codigo) -> bool:
        """Verifica si la secretaria tiene acceso autorizado para la carrera."""
        secretaria = self.info_carreras[self.carrera]["secretaria"]
        if secretaria["nombre"] == nombre and secretaria["apellido"] == apellido and secretaria["codigo"] == codigo:
            return True
        raise PermissionError("Secretaria no autorizada.")

    def _verificar_coordinadora(self, nombre, apellido, codigo) -> bool:
        """Verifica si la coordinadora tiene acceso autorizado para la carrera."""
        coordinadora = self.info_carreras[self.carrera]["coordinadora"]
        if coordinadora["nombre"] == nombre and coordinadora["apellido"] == apellido and coordinadora["codigo"] == codigo:
            return True
        raise PermissionError("Coordinadora no autorizada.")

    def _verificar_codigo_estudiante(self, codigo: str) -> None:
        """Verifica si un estudiante con un código dado existe en la base de datos de estudiantes."""
        codigos_existentes = [estudiante["codigo_estudiante"] for estudiante in self.__datos_estudiantes]
        if codigo not in codigos_existentes:
            return f"No existe un estudiante con el código '{codigo}'."
        return None
    
    # ----------------------------------- MÉTODOS DE CONSULTA Y LISTADOS --------------------------------------
    def lista_estudiantes(self) -> list:
        """Devuelve una lista de todos los estudiantes con su código, nombre y apellido."""
        return [(estudiante["codigo_estudiante"], estudiante["nombre"], estudiante["apellido"]) for estudiante in self.__datos_estudiantes]

    def info_estudiante(self, identificador: str | int) -> dict:
        """Devuelve la información completa de un estudiante dado su identificador (código o cédula)."""
        if isinstance(identificador, (str, int)):
            for estudiante in self.__datos_estudiantes:
                if estudiante["codigo_estudiante"] == identificador or estudiante["cedula"] == identificador:
                    return estudiante
            return f"Error: No se encontró un estudiante con el identificador '{identificador}'."
        return "Error: El identificador debe ser un string (código) o un entero (cédula)."

    def estado_general_estudiante(self, codigo_estudiante: str) -> dict:
        """Devuelve información sobre las unidades curriculares aprobadas, matriculadas y pendientes de un estudiante."""
        error = self._verificar_codigo_estudiante(codigo_estudiante)
        if error is not None:
            return error
        for estudiante in self.__datos_estudiantes:
            if estudiante["codigo_estudiante"] == codigo_estudiante:
                return {
                    "Estudiante": codigo_estudiante,
                    "UC Aprobadas": estudiante["uc_aprobadas"],
                    "UC Matriculadas": estudiante["uc_matriculadas"],
                    "UC Pendientes": estudiante["uc_pendientes"]
                }

    def clasificar_por_ingreso(self, ingreso: int) -> list:
        """Devuelve los estudiantes que ingresaron en un determinado año."""
        resultado = []
        for estudiante in self.__datos_estudiantes:
            if estudiante["ingreso"] == ingreso:
                resultado.append({
                    "codigo_estudiante": estudiante["codigo_estudiante"],
                    "nombre": estudiante["nombre"],
                    "apellido": estudiante["apellido"],
                    "año_ingreso": ingreso
                })
        if not resultado:
            return f"No hay ningún estudiante que haya ingresado en el año {ingreso}."
        return resultado

    def estado_uc_general(self, codigo_uc: str) -> list:
        """Devuelve el estado de una unidad curricular (UC) en todos los estudiantes."""
        error = self.__plan._verificar_codigo_uc(codigo_uc)
        if error is not None:
            return error
        resultado = []
        for estudiante in self.__datos_estudiantes:
            estado = self._estado_uc_auxiliar(estudiante, codigo_uc)
            if estado is not None:
                resultado.append({
                    "codigo_estudiante": estudiante["codigo_estudiante"],
                    "nombre": estudiante["nombre"],
                    "apellido": estudiante["apellido"],
                    "estado": estado
                })
        if not resultado:
            return f"La unidad curricular '{codigo_uc}' no ha sido cursada por ningún estudiante."
        return resultado

    def estado_uc_estudiante(self, codigo_estudiante: str, codigo_uc: str) -> dict:
        """Devuelve el estado de una unidad curricular (UC) para un estudiante específico."""
        error = self._verificar_codigo_estudiante(codigo_estudiante)
        if error is not None:
            return error
        error = self.__plan._verificar_codigo_uc(codigo_uc)
        if error is not None:
            return error
        for estudiante in self.__datos_estudiantes:
            if estudiante["codigo_estudiante"] == codigo_estudiante:
                estado = self._estado_uc_auxiliar(estudiante, codigo_uc)
                return {
                    "codigo_estudiante": estudiante["codigo_estudiante"],
                    "nombre": estudiante["nombre"],
                    "apellido": estudiante["apellido"],
                    "estado": estado or "Aún no cursada"
                }

    # --------------------------------- MÉTODOS DE INSCRIPCIÓN Y MODIFICACIÓN ---------------------------------
    def matricular_estudiante_uc(self, codigo_estudiante: str, *codigos_UC: str) -> str:
        """Matricula a un estudiante en una o más unidades curriculares (UC)."""
        error = self._verificar_codigo_estudiante(codigo_estudiante)
        if error is not None:
            return error
        mensajes = []
        for estudiante in self.__datos_estudiantes:
            if estudiante["codigo_estudiante"] == codigo_estudiante:
                for codigo in codigos_UC:
                    error = self.__plan._verificar_codigo_uc(codigo)
                    if error is not None:
                        mensajes.append(f"[{codigo}] {error}")
                        continue
                    if codigo in estudiante["uc_aprobadas"]:
                        mensajes.append(f"[{codigo}] Ya fue aprobada.")
                        continue
                    if codigo in estudiante["uc_matriculadas"]:
                        mensajes.append(f"[{codigo}] Ya está matriculada.")
                        continue
                    previas = self.__plan.previas_de_uc(codigo)
                    if not all(uc_previa in estudiante["uc_aprobadas"] for uc_previa in previas):
                        mensajes.append(f"[{codigo}] No se puede matricular. Faltan previas.")
                        continue
                    if codigo in estudiante["uc_pendientes"]["recursar"]:
                        estudiante["uc_pendientes"]["recursar"].remove(codigo)
                    estudiante["uc_matriculadas"].append(codigo)
                    mensajes.append(f"[{codigo}] Matriculación exitosa.")
                break
        estudiante["uc_matriculadas"].sort(key=lambda uc: (int(uc[1]), int(uc[4:])))
        GestorJSON.guardar_json(self.__ruta_estudiantes, self.__datos_estudiantes)
        return " - ".join(mensajes)

    def desmatricular_estudiante_uc(self, codigo_estudiante: str, *codigos_UC: str) -> str:
        """Desmatricula a un estudiante de una unidad curricular (UC)."""
        error = self._verificar_codigo_estudiante(codigo_estudiante)
        if error is not None:
            return error
        mensajes = []
        for estudiante in self.__datos_estudiantes:
            if estudiante["codigo_estudiante"] == codigo_estudiante:
                for codigo in codigos_UC:
                    error = self.__plan._verificar_codigo_uc(codigo)
                    if error is not None:
                        mensajes.append(f"[{codigo}] {error}")
                        continue
                    if codigo not in estudiante["uc_matriculadas"]:
                        mensajes.append(f"[{codigo}] No está matriculada.")
                        continue
                    estudiante["uc_matriculadas"].remove(codigo)
                    mensajes.append(f"[{codigo}] Desmatriculación exitosa.")
                break
        GestorJSON.guardar_json(self.__ruta_estudiantes, self.__datos_estudiantes)
        return " - ".join(mensajes)

    # ----------------------------------- MÉTODOS DE MODIFICACIÓN DE CARRERA -----------------------------------
    def modificar_info_carrera(self, clave: str, nuevo_valor) -> str:
        """Modifica el valor de una clave específica en la información de una carrera dentro del archivo JSON."""
        if clave not in self.info_carreras[self.carrera]:
            return f"Error: La clave '{clave}' no existe en la información de la carrera '{self.carrera}'."
        if self.info_carreras[self.carrera][clave] == nuevo_valor:
            return f"El valor de '{clave}' ya es '{nuevo_valor}', no se realizaron cambios."
        try:
            GestorJSON.modificar_info_carrera(self.ruta_carreras, self.carrera, clave, nuevo_valor)
            self.info_carreras = GestorJSON.abrir_json(self.ruta_carreras)
            return f"Modificación exitosa: '{clave}' de '{self.carrera}' actualizado."
        except Exception as e:
            return f"Error al modificar la información: {e}"

    def agregar_carrera(self, nombre_carrera: str, plan_path: str, estudiantes_path: str, nombre_secretaria: str, apellido_secretaria: str, codigo_secretaria: str, nombre_coordinadora: str, apellido_coordinadora: str, codigo_coordinadora: str) -> str:
        """Agrega una nueva carrera al archivo JSON de información de las carreras."""
        if nombre_carrera in self.info_carreras:
            return f"Error: La carrera '{nombre_carrera}' ya existe."
        datos_carrera = {
            "plan_path": plan_path,
            "estudiantes_path": estudiantes_path,
            "secretaria": {
                "nombre": nombre_secretaria,
                "apellido": apellido_secretaria,
                "codigo": codigo_secretaria
            },
            "coordinadora": {
                "nombre": nombre_coordinadora,
                "apellido": apellido_coordinadora,
                "codigo": codigo_coordinadora
            }
        }
        try:
            GestorJSON.agregar_carrera(self.ruta_carreras, nombre_carrera, datos_carrera)
            return f"Carrera '{nombre_carrera}' agregada exitosamente."
        except Exception as e:
            return f"Error al agregar carrera: {e}"


class Estudiante:
    """ Representa a un estudiante dentro del sistema académico. 
        Esta clase modela los datos personales y académicos del estudiante, incluyendo su historial de unidades curriculares aprobadas, matriculadas y pendientes. """

    def __init__(self, nombre: str, apellido: str, cedula: int, carrera: str, sistema:object, plan:object):
        """Inicializa una nueva instancia de Estudiante con sus datos personales.

        Parámetros:
            nombre (str): Nombre del estudiante.
            apellido (str): Apellido del estudiante.
            cedula (int): Cédula de identidad del estudiante.
            carrera (str): Carrera académica del estudiante.
            sistema (object): Instancia del sistema asociado.
            plan (object): Instancia del plan de estudios asociado."""
        
        self.nombre = nombre
        self.apellido = apellido
        self.__cedula = cedula
        self.carrera = carrera

        self.__plan = plan
        self.__sistema = sistema

        info = self.__sistema.info_estudiante(cedula)
        self.__codigo_estudiante = info["codigo_estudiante"]
        self.__ingreso = info["ingreso"]                        
        self.__uc_aprobadas = info["uc_aprobadas"]              
        self.__uc_matriculadas = info["uc_matriculadas"]        
        self.__uc_pendientes = info["uc_pendientes"]               
    
    @property
    def ver_codigo_estudiante(self) -> str:
        """Devuelve el código único del estudiante."""
        return self.__codigo_estudiante

    @property
    def ver_cedula(self) -> int:
        """Devuelve la cédula de identidad del estudiante."""
        return self.__cedula

    @property
    def ver_ingreso(self) -> int:
        """Devuelve el año de ingreso del estudiante."""
        return self.__ingreso

    @property
    def ver_uc_aprobadas(self) -> list:
        """Devuelve la lista de UC aprobadas por el estudiante."""
        return self.__uc_aprobadas

    @property
    def ver_uc_matriculadas(self) -> list:
        """Devuelve la lista de UC en las que el estudiante está actualmente matriculado."""
        return self.__uc_matriculadas

    @property
    def ver_uc_pendientes(self) -> dict:
        """Devuelve la lista de UC que el estudiante tiene pendientes."""
        return self.__uc_pendientes
    
    def matricularse_uc(self, *codigos_uc: str) -> str:
        """Matricula al estudiante en una o varias UCs.

        Parámetro:
            codigo_uc (str): Código de la UC a la que desea matricular."""
        
        return self.__sistema.matricular_estudiante_uc(self.__codigo_estudiante, *codigos_uc)
    
    def desmatricularse_uc(self, *codigos_uc: str) -> str:
        """Desmatricula al estudiante de una o varias UCs

        Parámetro:
            codigo_uc (str): Código de la UC a la que desea desmatricular."""
        
        return self.__sistema.desmatricular_estudiante_uc(self.__codigo_estudiante, *codigos_uc)

    def inscribirse(self, codigo_uc: str, estado:str) -> str:
        """Matricula al estudiante a un examen, tutoria o examen único.

        Parámetro:
            codigo_uc (str): Código de la UC a la que desea inscribirse.
            estado (str): Nombre del estado ("examen", "tutoria", "examen_unico")."""
       
        return self.__sistema.inscripcion(self.__codigo_estudiante, codigo_uc, estado)

    def ver_previas_uc(self, codigo_uc: str) -> list:
        """Devuelve las previaturas necesarias para una UC según el plan de estudios.

        Parámetro:
            codigo_uc (str): Código de la UC.

        Retorna:
            list: Lista de códigos de UCs previas requeridas."""
               
        return self.__plan.previas_de_uc(codigo_uc)
    
    def creditos_obtenidos(self) -> int:
        """Calcula el total de créditos obtenidos por el estudiante.

        Retorna:
            int: Suma de créditos correspondientes a las unidades curriculares aprobadas."""
        
        return self.__plan.sumar_creditos(self.__uc_aprobadas)  

class Secretaria:
    """ Representa al rol administrativo de Secretaría dentro del sistema académico. 
        Esta clase permite a la secretaria gestionar inscripciones, calificaciones y la administración de estudiantes dentro de una carrera universitaria."""
    
    def __init__(self, nombre: str, apellido: str, codigo: str, carrera: str, sistema:object, plan:object):
        """Inicializa una nueva secretaria con sus datos personales y académicos.

        Parámetros:
            nombre (str): Nombre de la secretaria.
            apellido (str): Apellido de la secretaria.
            codigo (str): Código de identificación de la secretaria.
            carrera (str): Carrera académica que gestiona.
            sistema (object): Instancia del sistema asociado.
            plan (object): Instancia del plan de estudios asociado."""

        self.nombre = nombre
        self.apellido = apellido
        self.carrera = carrera
    
        self.__plan = plan
        self.__sistema = sistema
        
        self.__sistema._verificar_secretaria(nombre, apellido, codigo)


    def matricular_estudiante_uc(self, codigo_estudiante: str, *codigo_uc: str) -> str:
        """Matricula a un estudiante en una unidad curricular.

        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            codigo_uc (str): Código de la unidad curricular."""
        
        return self.__sistema.matricular_estudiante_uc(codigo_estudiante, *codigo_uc)

    def desmatricular_estudiante_uc(self, codigo_estudiante: str, *codigo_uc: str) -> str:
        """Desmatricula a un estudiante de una unidad curricular.

        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            codigo_uc (str): Código de la unidad curricular."""
        
        return self.__sistema.desmatricular_estudiante_uc(codigo_estudiante, *codigo_uc)

    def inscribir_estudiante(self, codigo_estudiante: str, codigo_uc: str, estado: str) -> str:
        """Inscribe a un estudiante en un modalidad (examen, tutoría o examen único).
        
        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            codigo_uc (str): Código de la unidad curricular a la que se desea inscribir.
            estado (str): Modalidad de inscripción ('examen', 'tutoria' o 'examen_unico').

        Retorna:
            str: Mensaje con el resultado de la inscripción (éxito o descripción del error)."""
        
        return self.__sistema.inscripcion(codigo_estudiante, codigo_uc, estado)
    
    def poner_nota_estudiante(self, codigo_estudiante: str, codigo_uc: str, estado:str, nota: float) -> str:
        """Registra la nota obtenida por un estudiante en un estado (examen, tutoría, examen único) y actualiza su situación académica.
        
        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            codigo_uc (str): Código de la unidad curricular evaluada.
            estado (str): Modalidad de evaluación ('examen', 'tutoria' o 'examen_unico').
            nota (float): Nota obtenida por el estudiante.

        Retorna:
            str: Mensaje indicando si el registro fue exitoso o describiendo el error."""
            
        return self.__sistema.poner_nota(codigo_estudiante, codigo_uc, estado, nota)

    def lista_inscritos(self, codigo_UC: str, tipo: str = None) -> list:
        """Obtiene la lista de estudiantes inscritos en una unidad curricular (UC), según el tipo de inscripción.

        Parámetros:
            codigo_UC (str): Código de la unidad curricular.
            tipo (str, opcional): Tipo de inscripción ('examen', 'tutoria', etc.).

        Retorna:
            list: Lista de estudiantes inscritos o mensaje en caso de error."""
        
        return self.__sistema.obtener_inscritos(codigo_UC, tipo)

class Coordinadora:
    """ Representa a la Coordinadora académica de la carrera. 
        Esta clase permite gestionar el plan de estudio, estudiantes y unidades curriculares, así como registrar calificaciones. """

    def __init__(self, nombre: str, apellido: str, codigo: str, carrera: str, sistema:object, plan:object):
        """Inicializa una nueva coordinadora con sus datos personales y académicos.

        Parámetros:
            nombre (str): Nombre de la coordinadora.
            apellido (str): Apellido de la coordinadora.
            codigo (str): Código identificador de la coordinadora.
            carrera (str): Carrera asignada a la coordinación.
            sistema (object): Instancia del sistema asociado.
            plan (object): Instancia del plan de estudios asociado."""
     
        self.nombre = nombre
        self.apellido = apellido
        self.carrera = carrera
    
        self.__plan = plan
        self.__sistema = sistema
        
        self.__sistema._verificar_coordinadora(nombre, apellido, codigo)

    def lista_inscritos(self, codigo_UC: str, tipo: str = None) -> list:
        """Obtiene la lista de estudiantes inscritos en una unidad curricular (UC), según el tipo de inscripción.

        Parámetros:
            codigo_UC (str): Código de la unidad curricular.
            tipo (str, opcional): Tipo de inscripción ('examen', 'tutoria', etc.).

        Retorna:
            list: Lista de estudiantes inscritos o mensaje en caso de error."""
            
        return self.__sistema.obtener_inscritos(codigo_UC, tipo)

    def poner_nota_estudiante(self, codigo_estudiante: str, codigo_uc: str, estado:str, nota: float) -> str:
        """Registra la nota obtenida por un estudiante en un estado (examen, tutoría, examen único) y actualiza su situación académica.
        
        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            codigo_uc (str): Código de la unidad curricular evaluada.
            estado (str): Modalidad de evaluación ('examen', 'tutoria' o 'examen_unico').
            nota (float): Nota obtenida por el estudiante.

        Retorna:
            str: Mensaje indicando si el registro fue exitoso o describiendo el error."""
            
        return self.__sistema.poner_nota(codigo_estudiante, codigo_uc, estado, nota)

    def agregar_estudiante(self, codigo_estudiante: str, nombre_estudiante: str, apellido_estudiante: str, cedula_estudiante: int, ingreso_estudiante: int, uc_aprobadas: list = [], uc_matriculadas: list = []) -> str:
        """Agrega un nuevo estudiante al sistema.

        Parámetros:
            codigo_estudiante (str): Código del estudiante.
            nombre_est (str): Nombre del estudiante.
            apellido_est (str): Apellido del estudiante.
            cedula (int): Cédula de identidad.
            ingreso (int): Año de ingreso.
            uc_aprobadas (list, opcional): Lista de unidades curriculares aprobadas.
            uc_matriculadas (list, opcional): Lista de unidades curriculares en las que está inscripto.
            uc_pendientes (dict, opcional): Unidades curriculares pendientes con motivo."""
        
        return self.__sistema.agregar_estudiante(codigo_estudiante, nombre_estudiante, apellido_estudiante, cedula_estudiante, ingreso_estudiante, uc_aprobadas, uc_matriculadas)
    
    def eliminar_estudiante(self, codigo_estudiante: str) -> str:
        """Elimina a un estudiante de la base de datos de los estudiantes.

        Parámetros:
            codigo_estudiante (str): Código del estudiante a eliminar.

        Retorna:
            str: Mensaje indicando si la eliminación fue exitosa o no."""
        
        return self.__sistema.eliminar_estudiante(codigo_estudiante)

class GestorAcademico:
    """ Clase encargada de centralizar la creación de objetos académicos. """
    
    def __init__(self, ruta_carreras):
        """Inicializa el gestor académico con la ruta donde se encuentra el JSON con información de las carreras.

        Parámetros:
            ruta_carreras (str): Ruta al archivo JSON que contiene los datos de las distintas carreras."""
        
        self.__ruta_carreras = ruta_carreras

    def crear_plan_de_estudios(self, carrera):
        """Crea una instancia del plan de estudios para una carrera específica.

        Parámetros:
            carrera (str): Nombre de la carrera a la que pertenece el plan de estudios.

        Retorna:
            PlanEstudio: Objeto que representa el plan de estudios de la carrera."""
        
        return PlanEstudio(self.__ruta_carreras, carrera)
    
    def crear_sistema(self, carrera):
        """Crea el sistema asociado a una carrera específica.

        Parámetros:
            carrera (str): Nombre de la carrera a la que pertenece el sistema.

        Retorna:
            Sistema: Objeto que representa el sistema de una carrera y permite gestionar sus estudiantes."""
        
        return Sistema(self.__ruta_carreras, self.crear_plan_de_estudios(carrera))
    
    def crear_estudiante(self, nombre, apellido, cedula, carrera):
        """Crea una instancia del estudiante con sus datos personales y académicos asociados.

        Parámetros:
            nombre (str): Nombre del estudiante.
            apellido (str): Apellido del estudiante.
            cedula (int): Cédula de identidad del estudiante.
            carrera (str): Carrera a la que pertenece el estudiante.

        Retorna:
            Estudiante: Objeto que representa a un estudiante."""
        
        plan = self.crear_plan_de_estudios(carrera)
        sistema = self.crear_sistema(carrera)
        
        return Estudiante(nombre, apellido, cedula, carrera, sistema, plan)

    def crear_secretaria(self, nombre, apellido, codigo, carrera):
        """Crea una instancia de secretaria académica con acceso administrativo al sistema.

        Parámetros:
            nombre (str): Nombre de la secretaria.
            apellido (str): Apellido de la secretaria.
            codigo (str): Código de identificación para operar como secretaria.
            carrera (str): Carrera que gestiona.

        Retorna:
            Secretaria: Objeto que representa a una secretaria."""
        
        plan = self.crear_plan_de_estudios(carrera)
        sistema = self.crear_sistema(carrera)
        
        return Secretaria(nombre, apellido, codigo, carrera, sistema, plan)
    
    def crear_coordinadora(self, nombre, apellido, codigo, carrera):
        """Crea una instancia de coordinadora académica con facultades ampliadas de gestión.

        Parámetros:
            nombre (str): Nombre de la coordinadora.
            apellido (str): Apellido de la coordinadora.
            codigo (str): Código de identificación para operar como coordinadora.
            carrera (str): Carrera que gestiona.

        Retorna:
            Coordinadora: Objeto que representa a una coordinadora."""
        
        plan = self.crear_plan_de_estudios(carrera)
        sistema = self.crear_sistema(carrera)
        
        return Coordinadora(nombre, apellido, codigo, carrera, sistema, plan)